/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class VanEjecutiva extends Abstract class {

    private boolean aireAcondicionado;

    public VanEjecutiva(String string1, String string2, int int3, int int4, boolean boolean5) {
        // Constructor a resolver...
    }

    public String toString() {
        // Método a resolver...
        return "";
    }

    public void realizarServiciosTuristicos() {
        // Método a resolver...
    }

}