/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class ColectivoTuristico extends Abstract class {

    private int cantidadPisos;

    public ColectivoTuristico(String string1, String string2, int int3, int int4, int int5) {
        // Constructor a resolver...
    }

    public String toString() {
        // Método a resolver...
        return "";
    }

    public void realizarServiciosTuristicos() {
        // Método a resolver...
    }

}