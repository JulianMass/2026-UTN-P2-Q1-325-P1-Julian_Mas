/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class AdministradorVehiculos extends Abstract class {

    private Vehiculo[] vehiculos;

    public void agregarVehiculo() {
        // Método a resolver...
    }

    public void realizarServiciosTuristicos() {
        // Método a resolver...
    }

    public void mostrarVehiculos() {
        // Método a resolver...
    }

    public void ordenarPorAnio() {
        // Método a resolver...
    }

    public void ordenarPorCapacidad() {
        // Método a resolver...
    }

}