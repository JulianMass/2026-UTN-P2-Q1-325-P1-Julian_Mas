/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class LanchaTuristica extends Abstract class implements TipoMotor {

    private TipoMotor tipoMotor;

    public LanchaTuristica(String string1, String string2, int int3, int int4, TipoMotor tipomotor5) {
        // Constructor a resolver...
    }

    public String toString() {
        // Método a resolver...
        return "";
    }

    public void realizarServiciosTuristicos() {
        // Método a resolver...
    }

}