/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public abstract class Abstract class {

    private String patente;
    private String marca;
    private int capacidadPasajeros;
    private int anioFabricacion;

    public void Vehiculo(String string1, String string2, int int3, int int4) {
        // Método a resolver...
    }

    public void getPatente() {
        // Método a resolver...
    }

    public void getCapacidadPasajeros() {
        // Método a resolver...
    }

    public void getAnioFabricacion() {
        // Método a resolver...
    }

    public void realizarServiciosTuristicos() {
        // Método a resolver...
    }

    public boolean equals(Object obj object obj1) {
        // Método a resolver...
        return false;
    }

    public int compareTo(Vehiculo v vehiculo v1) {
        // Método a resolver...
        return 0;
    }

    public String toString() {
        // Método a resolver...
        return "";
    }

}